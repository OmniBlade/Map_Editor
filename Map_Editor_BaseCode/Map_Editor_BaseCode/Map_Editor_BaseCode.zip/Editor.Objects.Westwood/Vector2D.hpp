#pragma once
class Vector2D
{
public:

	int x = 0;
	int y = 0;
	int z = 0;

};

