#pragma once
class Foundation
{
public:
	Foundation();
	~Foundation();
};

