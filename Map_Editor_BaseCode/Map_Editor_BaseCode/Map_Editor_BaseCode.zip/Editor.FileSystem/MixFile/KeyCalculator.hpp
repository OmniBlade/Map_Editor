#pragma once

void get_blowfish_key(const byte* s, byte* d);
