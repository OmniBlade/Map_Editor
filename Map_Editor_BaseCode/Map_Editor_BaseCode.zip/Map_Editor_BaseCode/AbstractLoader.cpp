#include "stdafx.h"
#include "AbstractLoader.hpp"


AbstractLoader::AbstractLoader()
{
}


AbstractLoader::~AbstractLoader()
{
}
