#include "stdafx.h"
#include "MapAssetLoader.hpp"


MapAssetLoader::MapAssetLoader()
{
}


MapAssetLoader::~MapAssetLoader()
{
}
