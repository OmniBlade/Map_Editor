#pragma once
class MapLoader
{
public:
	MapLoader();

private:

};

