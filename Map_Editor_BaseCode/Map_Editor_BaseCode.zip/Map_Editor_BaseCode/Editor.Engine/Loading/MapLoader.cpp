#include "stdafx.h"
#include "MapLoader.hpp"


MapLoader::MapLoader()
{

}

