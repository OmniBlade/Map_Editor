#pragma once
class MapAssetLoader
{
public:
	MapAssetLoader();
	~MapAssetLoader();
};

