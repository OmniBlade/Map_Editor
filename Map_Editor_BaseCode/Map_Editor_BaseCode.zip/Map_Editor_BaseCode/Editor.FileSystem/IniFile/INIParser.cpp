#include "stdafx.h"
#include "INIParser.hpp"


INIParser::INIParser()
{
}


INIParser::~INIParser()
{
}
