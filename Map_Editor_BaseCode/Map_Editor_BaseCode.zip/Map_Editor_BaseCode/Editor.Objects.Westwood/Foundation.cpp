#include "stdafx.h"
#include "Foundation.hpp"


Foundation::Foundation()
{
}


Foundation::~Foundation()
{
}
