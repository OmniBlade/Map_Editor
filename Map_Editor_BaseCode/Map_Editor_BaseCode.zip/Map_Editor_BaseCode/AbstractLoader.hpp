#pragma once
class AbstractLoader
{
public:
	AbstractLoader();
	~AbstractLoader();
};

