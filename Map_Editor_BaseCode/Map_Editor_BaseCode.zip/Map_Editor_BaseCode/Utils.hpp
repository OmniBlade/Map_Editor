#pragma once

#include <sstream>
#include <string>
class Utils
{
public:

	static std::string toString(double _value);
};

